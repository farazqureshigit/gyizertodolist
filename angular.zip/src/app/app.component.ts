import { Component,Renderer2, ViewChild } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private render:Renderer2){}




  todos:any =[
    // {
    //  title: 'Birthday',
     
    //  priority: 3
    // },
 
    // {
    //  title: 'Meeting',
     
    //  priority: 1
    // },
 
 
   ];
 
   addTodo(newTodoTitle:any,newTodoPriority:any){
   
   var newTodo = {
     title: newTodoTitle,
     priority: newTodoPriority,
   };
   this.todos.push(newTodo);
   newTodoTitle = '';
   newTodoPriority = '';
 }
 dropopen:boolean=false
 public isupdateactive: boolean = false
 onbtnclick(i:any){
  this.dropopen = !this.dropopen;
 }


 edit(i:any){
console.log(i,'value');

 }

 delete(i:any){
  this.todos.splice(i,1)
 }

 del(){
  
 }
 
//  deleteTodo(todo:any){
//    this.todos = this.todos.filter(t => t.title !== todo.title);
//  }
}
